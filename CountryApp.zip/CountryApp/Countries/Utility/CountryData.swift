//
//  CountryData.swift
//  Countries
//
//  Created by Nandana on 08/09/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import Foundation
import ObjectMapper

class CountryData: NSObject, Mappable
{
    
    var countryFlag: String?
    var countryName: String?
    var capital: String?
    var callingCode: [String]?
    var region: String?
    var subRegion: String?
    var timeZone: [String]?
    var currencies: [Currencies]?
    var languages:[CountryLanguage]?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        countryFlag      <- map[CountryConstants.countryFlag]
        countryName      <- map[CountryConstants.countryName]
        capital          <- map[CountryConstants.capital]
        callingCode      <- map[CountryConstants.callingCodes]
        region           <- map[CountryConstants.region]
        subRegion        <- map[CountryConstants.subregion]
        timeZone         <- map[CountryConstants.timezones]
        currencies       <- map[CountryConstants.currencies]
        languages        <- map[CountryConstants.languages]
        
    }
}

class CountryLanguage: NSObject, Mappable
{
    var nativeName: String?
    var iso639_2: String?
    var name: String?
    var iso639_1: String?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        nativeName         <- map[CountryConstants.nativeName]
        iso639_2           <- map[CountryConstants.iso639_2]
        name               <- map[CountryConstants.name]
        iso639_1           <- map[CountryConstants.iso639_1]
        
    }
    
    
}


class Currencies: NSObject, Mappable 
{
    var name: String?
    var symbol: String?
    var code: String?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        name         <- map[CountryConstants.name]
        symbol          <- map[CountryConstants.symbol]
        code           <- map[CountryConstants.code]
        
    }
    
    
}


