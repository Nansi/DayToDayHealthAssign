//
//  CountryConstants.swift
//  Countries
//
//  Created by Nandana on 08/09/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import UIKit

class CountryConstants: NSObject {
    
    static let countryFlag = "flag"
    static let countryName = "name"
    static let capital = "capital"
    static let callingCodes = "callingCodes"
    static let region = "region"
    static let subregion = "subregion"
    static let timezones = "timezones"
    static let currencies = "currencies"
    static let languages = "languages"
    static let nativeName = "nativeName"
    static let iso639_2 = "iso639_2"
    static let name = "name"
    static let iso639_1 = "iso639_1"
    static let symbol = "symbol"
    static let code = "code"

}
