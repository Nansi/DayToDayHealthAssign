//
//  ServiceHandler.swift
//  Countries
//
//  Created by Nandana on 08/09/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
//import AlamofireImage

enum NetworkError: Error {
    case failure
    case success
}

class ServiceHandler: NSObject {

    var searchResults = [JSON]()
    
    func search(searchText: String, completionHandler: @escaping ([JSON]?, NetworkError) -> ()) {
        
        let urlToSearch = "https://restcountries.eu/rest/v2/name/\(searchText)"
        print("show the urltosearch \(urlToSearch)")
        Alamofire.request(urlToSearch).responseJSON { response in
            guard let data = response.data else {
                completionHandler(nil, .failure)
                return
            }
            
            let json = try? JSON(data: data)
            let results = json?.arrayValue
            guard let empty = results?.isEmpty, !empty else {
                completionHandler(nil, .failure)
            return }
            
            print("Show the results  \(String(describing: results))")
           completionHandler(results, .success)
        }
    }
    
    func fetchImage(url: String, completionHandler: @escaping (UIImage?, NetworkError) -> ()) {
     
        Alamofire.request(url).responseData { responseData in
        print("Show image url   \(url)")
            guard let imageData = responseData.data else {
                completionHandler(nil, .failure)
                return
            }

            guard let image = UIImage(data: imageData) else {
                completionHandler(nil, .failure)
                return
            }

            completionHandler(image, .success)
        }
    }
}
