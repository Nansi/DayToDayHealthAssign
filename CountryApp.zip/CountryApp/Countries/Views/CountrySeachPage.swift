//
//  CountrySeachPage.swift
//  Countries
//
//  Created by Nandana on 08/09/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import CoreData
import SwiftSVG

class CountrySeachPage: UITableViewController {

     var searchData = [CountryData]()
     let backgroundViewLabel = UILabel(frame: .zero)

    
     private let searchController = UISearchController(searchResultsController: nil)
     private let apiFetcher = ServiceHandler()
     private var previousRun = Date()
     private let minInterval = 0.05
    
        
    override func viewDidLoad() {
            super.viewDidLoad()
            self.navigationItem.title = "Country List"
            tableView.tableFooterView = UIView()
            setupTableViewBackgroundView()
            backgroundViewLabel.isHidden = false
            setupSearchBar()
        }
        
    private func setupTableViewBackgroundView() {
        
            backgroundViewLabel.textColor = .darkGray
            backgroundViewLabel.numberOfLines = 0
            backgroundViewLabel.text = "No results to show "
            backgroundViewLabel.textAlignment = NSTextAlignment.center
            backgroundViewLabel.font.withSize(20)
            tableView.backgroundView = backgroundViewLabel
        
        }
        
        private func setupSearchBar() {
            searchController.searchBar.delegate = self
            searchController.dimsBackgroundDuringPresentation = false
            searchController.hidesNavigationBarDuringPresentation = false
            searchController.searchBar.placeholder = "Search any Topic"
            definesPresentationContext = true
            tableView.tableHeaderView = searchController.searchBar
        }
        
        override func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return searchData.count
        }
        
        override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SearchDataTableViewCell",for: indexPath) as! SearchDataTableViewCell
   
            if searchData.count == 0
            {
                backgroundViewLabel.isHidden = false
            }
            else
            {
                 backgroundViewLabel.isHidden = true
            }
            cell.name.text = searchData[indexPath.row].countryName
            if let url = searchData[indexPath.row].countryFlag
            {
//                apiFetcher.fetchImage(url: url, completionHandler: { image, _ in
//                    cell.flag.image = image
//                })
                let svgURL = URL(string: url)!

                let countryFlag = UIView(SVGURL: svgURL) { (svgLayer) in
                    svgLayer.resizeToFit(cell.flag.bounds)
                }
                cell.flag.addSubview(countryFlag)

            }
            DispatchQueue.main.async {
                MakeActivityIndicator.sharedInstance.hideActivityIndicator(uiView: self.view)
            }

            return cell
        }
        
        override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
            let details = storyboard?.instantiateViewController(withIdentifier: "CountryDetailsPage") as! CountryDetailsPage            
            details.searchResults = searchData[indexPath.row]
            self.navigationController?.pushViewController(details, animated: true)
        }
  
}
    
extension CountrySeachPage: UISearchBarDelegate {
        
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            searchData.removeAll()
            guard let textToSearch = searchBar.text, !textToSearch.isEmpty else {
                return
            }
            
            if Date().timeIntervalSince(previousRun) > minInterval {
                previousRun = Date()
                fetchResults(for: textToSearch)
            }
        }
        
        func fetchResults(for text: String) {
            print("Text Searched: \(text)")
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            if Reachability.isConnectedToNetwork() == true
            {
                //Fetch data from URL
                print(" Network Access is there")
                searchData.removeAll()
                UIApplication.shared.isNetworkActivityIndicatorVisible = true
                MakeActivityIndicator.sharedInstance.showActivityIndicator(uiView:self.view)
                apiFetcher.search(searchText: text, completionHandler: {
                [weak self] results, error in
                if case .failure = error {
                    return
                }
                
                guard let results = results, !results.isEmpty else {
                    return
                }
                   
                for status in results {
                    let paramsJSON = JSON(status)
                    
                    let paramsString = paramsJSON.rawString(String.Encoding.utf8, options: JSONSerialization.WritingOptions.prettyPrinted)!
                    
                    let countryData = CountryData(JSONString: paramsString)
                    print("Show the country name \(String(describing: countryData?.countryName))")
                    self?.searchData.append(countryData!)
                }
                self?.tableView.reloadData()
                
            })
        }
        else
        {
            //No Netwrok , Fetch data from local DB
            print("No Network Access")
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Country")
            request.returnsObjectsAsFaults = false

            do {
                let result = try context.fetch(request)
                for data in result as! [CountryData] {
                    self.searchData.append(data)
                }

            } catch {

                print("Fetch Failed")
            }
            self.tableView.reloadData()
        }
            
      }
        
        
        func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
            searchData.removeAll()
            self.tableView.reloadData()
        }
        
}
