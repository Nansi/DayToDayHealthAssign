//
//  CountryDetailsPage.swift
//  Countries
//
//  Created by Nandana on 08/09/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import UIKit
import CoreData

class CountryDetailsPage: UIViewController {

    var searchResults:CountryData?
    @IBOutlet weak var detailTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Country Details"
    }
    
    @IBAction private func saveTapped(_ sender: UIButton)
    {
        print("Data need to save")
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext

        let callingcodedata = NSKeyedArchiver.archivedData(withRootObject: searchResults?.callingCode as Any)
        let timezonedata = NSKeyedArchiver.archivedData(withRootObject: searchResults?.timeZone as Any)
        let currencydata = NSKeyedArchiver.archivedData(withRootObject: searchResults?.currencies as Any)
        let languagedata = NSKeyedArchiver.archivedData(withRootObject: searchResults?.languages as Any)
     
        let entity = NSEntityDescription.entity(forEntityName: "Country", in: context)
        let newCountry = NSManagedObject(entity: entity!, insertInto: context)
        
        newCountry.setValue(searchResults?.capital, forKey: CountryConstants.capital)
        newCountry.setValue(searchResults?.countryFlag, forKey: CountryConstants.countryFlag)
        newCountry.setValue(searchResults?.countryName, forKey: CountryConstants.countryName)
        newCountry.setValue(searchResults?.region, forKey: CountryConstants.region)
        newCountry.setValue(searchResults?.subRegion, forKey: CountryConstants.subregion)
        newCountry.setValue(timezonedata, forKey: CountryConstants.timezones)
        newCountry.setValue(currencydata, forKey: CountryConstants.currencies)
        newCountry.setValue(languagedata, forKey: CountryConstants.languages)
        newCountry.setValue(callingcodedata, forKey: CountryConstants.callingCodes)
 
        do {
            
            try context.save()
            
        } catch {
            
            print("Failed saving")
        }

    }
 
}
extension CountryDetailsPage : UITableViewDataSource, UITableViewDelegate
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
     self.detailTableView.register(UINib.init(nibName: "DetailCountryTableViewCell", bundle: nil), forCellReuseIdentifier:"DetailCountryTableViewCell")
    let tablecell = detailTableView.dequeueReusableCell(withIdentifier: "DetailCountryTableViewCell", for: indexPath) as! DetailCountryTableViewCell
    
       let urlstring = searchResults?.countryFlag
       //let url = URL(string:urlstring!)
//       // let url = URL(string:"https://www.winni.in/celebrate-relations/wp-content/uploads/2018/06/roses-768x503.jpg")
//       let data = try? Data(contentsOf: url!)
//        tablecell.Flag.image = UIImage(data: data!)
    
        let svgURL = URL(string: urlstring!)!
    
       let countryFlag = UIView(SVGURL: svgURL) { (svgLayer) in
           svgLayer.resizeToFit(tablecell.Flag.bounds)
      }
       tablecell.Flag.addSubview(countryFlag)
       tablecell.Countryname.text = searchResults?.countryName
       tablecell.Capital.text = searchResults?.capital
       tablecell.Region.text = searchResults?.region
       tablecell.Subregion.text = searchResults?.subRegion
        for zoneitem in (searchResults?.timeZone)!
        {
            tablecell.Zone.text = tablecell.Zone.text! + "," + zoneitem
            
        }
        for codeitem in (searchResults?.callingCode)!
        {
            tablecell.Code.text = tablecell.Code.text! + codeitem
        }
        for item in (searchResults?.currencies)!
        {
            tablecell.Currency.text = "Code:" + item.code! + "," + " Name:" +  item.name! + "," + " Symbol:" + item.symbol!
        }
        for item in (searchResults?.languages)!
        {
            tablecell.Languages.text = item.name!
            //tablecell.Languages.text = item.nativeName! + item.iso639_1! + item.iso639_2! + item.name!
        }

    
        return tablecell
    }
    
 func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }
}
