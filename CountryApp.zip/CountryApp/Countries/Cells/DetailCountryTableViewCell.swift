//
//  DetailCountryTableViewCell.swift
//  Countries
//
//  Created by Nandana on 08/09/19.
//  Copyright © 2019 Nandana. All rights reserved.
//

import UIKit

class DetailCountryTableViewCell: UITableViewCell {

    //country flag, country name, capital, calling code, region, sub region, time zone, currencies and languages

    @IBOutlet weak var Flag: UIImageView!
    @IBOutlet weak var Countryname: UILabel!
    @IBOutlet weak var Capital: UILabel!
    @IBOutlet weak var Code: UILabel!
    @IBOutlet weak var Region: UILabel!
    @IBOutlet weak var Subregion: UILabel!
    @IBOutlet weak var Zone: UILabel!
    @IBOutlet weak var Currency: UILabel!  //currencies: [Currency]?
    @IBOutlet weak var Languages: UILabel!  //languages:[CountryLanguage]?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
